# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '5d40429fbab450c2b5979015501836e41f0032ba5cedd9032430fc3bccfb3fcfbe0f73c35fcb23e5e3b953500bb6a9c8de0fd08f5d2777ab4968c261c0923888'